<!-- pandoc README.md -o README.pdf -V geometry:margin=1in -->

# Dependencies

* R version 4.0.0 or higher.
* MUMPS and specified ordering libraries installed, with links to the static
libraries created in a default linker search path location (such as _/usr/local/lib_).

# Installation

If building from source, the contents of _odw/src/Makevars_ in the _src_
directory or archive may need modification to locate the MUMPS libraries and any
dependencies.

## From the source tree

In _Rodw_, that is the parent directory of _odw_ run

```shell
R CMD INSTALL odw
```

## From source package

```shell
R CMD INSTALL odw_2.1.6.tar.gz
```
## From binary package

```shell
R CMD INSTALL odw_2.1.6_<system-id>.tar.gz
```
where _\<system-id\>_ is a target specific string like _R_x86_64-pc-linux-gnu_.

# Overview

ODW seeks an optimal experimental design based on the A-value criterion with
respect to a specified objective (treatment) factor under a general linear
model. The model is defined in three main R formula arguments to the _odw()_
function that specify the terms in the _fixed_, _random_ and _residual_
components of the model. The _odw()_ call is of a functional style, where
variance structures and model constructors are applied to terms in the formulae
using special functions, for example, _ar1(x)_ specifies a first order
autoregressive model for the factor _x_. 

## Initial state

ODW requires:

* An **initial** data frame containing the design (eg, blocking), treatment
  (objective), and explanatory factors appearing in the model. It may be an
  advantage to permute the levels of the objective factor, respecting
  resolvability constraints, prior to the design search. The initial data frame
  is provided via the _data_ argument to odw().
* **Pre-specified** values for all random parameters. Default values are
  provided and if necessary can be replaced using the action of the
  _start.values_ argument. For example, the following sequence alters
  the pre-specified values for the _Variety_ variance component and the
  spatial correlation parameters for _Column_ and _Row_.

    ```R
    library(odw)
    data(rc400)
    sv <- odw(fixed = ~ 1, random = ~ Variety+Rep+Column+Row,
                permute = ~ Variety, swap = ~ Rep, search='random',
                residual = ~ ar1(Column):ar1(Row),
                data = rc400, maxit = 1000, start.values = TRUE)
    sv$vparameters.table$Value[c(1, 6, 7)] <- c(0.2, 0.3, 0.4)
    rc400.od <- odw(fixed = ~ 1, random = ~ Variety+Rep+Column+Row,
                    permute = ~ Variety, swap = ~ Rep, search = 'random',
                    residual = ~ ar1(Column):ar1(Row),
                    G.param = sv, R.param = sv,
                    data = rc400, maxit = 1000)
    ```

## Design search

The search for an optimal design is a discrete optimisation problem, involving
the interchange of pairs of experimental units; governed in _odw()_ by the
_search_ and _maxit_ arguments. These set the search method (_tabu_, for example)
and duration, respectively. The optimisation seeks to minimise the A-value of
the design, that is, the average pairwise variance of elementary contrasts among
the levels of the treatment factor. The default search method is _random_, the following
call will execute 1 tabu (with a random walk component) loop in the search for an
optimal design:

```R
    library(odw)
    data(rc400)
    rc400.od <- odw(fixed = ~ 1, random = ~ Variety+Rep+Column+Row,
                    permute = ~ Variety, swap = ~ Rep, search = 'tabu+rw',
                    residual = ~ ar1(Column):ar1(Row),
                    data = rc400, maxit = 1)
```


## The return object

On completion, the _odw_ object contains a _design_ component that is the
optimal permutation of the initial data frame with respect to the A-value of the
objective factor, and a _permutation_ component being the (final) sort vector
applied to the rows of the initial data frame. The above _odw_ object contains:

```R
> names(rc400.od)
[1] "permutation" "criterion"   "design"      "call"        "formulae"   
[6] "mf"          "R.param"     "G.param"
```

## Methods

The package provides _summary_, _plot_ and _update_ methods for _odw_ objects,
and a companion _plot.df()_ function to visualise a design represented in a data frame.
Images of the final design in _rc400.od_ from the above, and that of the initial
layout with the factor _Rep_ overlayed is rendered by:

```R
plot(rc400.od, theme = ~ Rep)
plot.df(layout = ~ Column + Row, theme = ~ Rep, data = rc400)
```

Permute factor _incidence_ and _concurrence_ tables are returned by the summary
method:

```R
rc400.sum <- summary(rc400.od)
> names(rc400.sum)
[1] "criterion"   "incidence"   "is.binary"   "concurrence"
```